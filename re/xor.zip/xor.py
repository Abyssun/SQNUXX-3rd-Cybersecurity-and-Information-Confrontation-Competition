# 给定的解密后的 ASCII 码值
password_dec = [

]

# 用于加密的 XOR 值
xor_value = 22

# 恢复 password_enc
password_enc = [num ^ xor_value for num in password_dec]

# 打印恢复后的 password_enc
print(" ".join(str(byte) for byte in password_enc))
#66 79 85 66 80 109 100 37 96 37 100 101 37 73 39 101 73 119 73 122 121 120 113 73 122 121 120 113 73 97 119 111 73 98 121 73 115 110 102 122 121 100 115 107