import random
import time


random.seed(int(time.time()))
rand = random.randint(0, 10**30)
flag = 0
en = flag ^ rand

print(en)


# Dec 28 2024 13:36:27
# 379881663933345252930034509999